```c-lms
course-code: ZQATestXX
course-name: NAME OF THE COURSE
unit-order: ZQATestXX - NAME OF THE COURSE {SEQUENCE #}
lesson-flow: none
```