```c-lms
activity-name: NAME THIS ACTIVITY COURSE Lesson Two
topic: Second  NAME THIS TOPIC
```

# THERE IS NO VIDEO ON THIS PAGE

```c-lms
topic: Next page
```

## New Topic

Now is the time for all good men to come to the aid of the party.  Bring whine, beer, cheesewiz, whatever you can.

---

* I just kept some of the words from the old course

---

You'll be referring to the same technologies, but now you will ask what should be done when:

* In preparation for the possibility of an attack?
* Abnormal inbound web traffic is detected?
* There is evidence your network is under attack from the outside?
* A DOS attack is underway?
* Anomalous activity is detected on the internal network?
* There is evidence an attacker has gained entry to the network?
* An attack is over?

On each of these scenarios, make sure you include specific instructions for how to respond for your chosen set of technologies.  E.g. check the systems log in Windows, check the Sophos firewall logs, filter by port, etc.

## Results

Compile your checklist and applicability to your chosen technologies.

```c-lms
topic: Next page
```

# In conclusion

This should start the third of three quizes ~ THEN the Examination pages.

```c-lms
start-activity: L02Q01 - Quiz Two
```

## Next is the exam

## FINALLY

* What you have all been waiting for