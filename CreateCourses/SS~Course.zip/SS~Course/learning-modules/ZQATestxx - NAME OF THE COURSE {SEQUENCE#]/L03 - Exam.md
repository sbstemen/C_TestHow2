```c-lms
activity-name: Exam Course Final Exam
topic: Stuff
```

# Final Exam Overview

---
This Final Exam will cover nothing.  You may encounter false questions, read the hints.

---
Good Luck!

```c-lms
start-activity: Practical Test Exam
```
