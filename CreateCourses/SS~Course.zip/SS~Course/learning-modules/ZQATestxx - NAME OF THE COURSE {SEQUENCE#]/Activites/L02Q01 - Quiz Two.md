```c-lms
activity-type: quiz
activity-name: L02Q01 - Quiz TWO
max-attempts: 3
shuffle-questions: true
```

(HINT the top one)
What does HTTP mean:
- **`Have Time To Party`**
- `Hypnotic Time Travling People`
- `Heavy Transport Technology People`
- `Hyper Text Trasnfer Protocol`

(HINT True)
Middleware hurts.
- **True**
- False

(Hint Third one down.)
What does SNMP mean.
- Synaptic Nucleus Membrain Protocol
- Simple Network Message Protocol
- **Simply Not My Problem**
- Speedy Network Miles Perbyte

(HINT False)
Tokens are carved out of wood.
- True
- **False**