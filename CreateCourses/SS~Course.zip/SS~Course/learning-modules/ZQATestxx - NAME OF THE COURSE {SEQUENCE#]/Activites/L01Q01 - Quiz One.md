```c-lms
activity-type: quiz
activity-name: L01Q01 - Quiz NAME MUST MATCH
max-attempts: 3
shuffle-questions: true
```

(FALSE)
Simply answer this one as false.
- True
    * A chicken will cross the road.
- **False**

(B~SECOND)
Answer this one with B, second answer?
- Data Center
- **Mee Mee Mee pick me I am the answer**
- Flowers
- Network

(D~LAST)
For web sites to work we need the bottom answer.
- HTTP
- HTTPS
- LAN
- **Electrons**
